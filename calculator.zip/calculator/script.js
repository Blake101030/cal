let display = document.getElementById('display');

function appendNumber(num) {
    display.value += num;
}

function appendOperator(operator) {
    display.value += operator;
}

function clearDisplay() {
    display.value = '';
}

function calculate() {
    try {
        display.value = eval(display.value);
    } catch (error) {
        display.value = 'Error';
    }
}

function convert(conversionType) {
    let inputValue = parseFloat(display.value);
    if (!isNaN(inputValue)) {
        switch (conversionType) {
            case 'dec-bin':
                display.value = inputValue.toString(2);
                break;
            case 'dec-oct':
                display.value = inputValue.toString(8);
                break;
            case 'dec-hex':
                display.value = inputValue.toString(16).toUpperCase();
                break;
            default:
                display.value = 'Invalid conversion';
        }
    } else {
        display.value = 'Invalid input';
    }
}
